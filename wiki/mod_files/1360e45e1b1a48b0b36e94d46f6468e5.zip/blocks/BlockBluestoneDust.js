import Block from "../Block.js";
import BoundingBox from "../BoundingBox.js";

const MAX_POWER = 15;
const TICK_DELAY = 1; // 1 world tick de délai, fiable

export default class BlockBluestoneDust extends Block {
    constructor(id, textureSlotId) {
        super(id, textureSlotId);
        this.description = "Bluestone Dust";
        this.hardness = 0.5;
    }

    shouldRenderFace(world, x, y, z, face) {
        return face === EnumBlockFace.TOP;
    }

    getTextureForFace(face, data, x, y, z, world) {
        // rendu inventaire / item 2D
        if (!world || typeof x !== 'number') {
            return 'bs-logic:bluestoneDust0000';
        }

        const isConnectable = (tx, tz) => this.canConnect(world, tx, y, tz);
        const up    = isConnectable(x, z - 1) ? "1" : "0";
        const down  = isConnectable(x, z + 1) ? "1" : "0";
        const left  = isConnectable(x - 1, z) ? "1" : "0";
        const right = isConnectable(x + 1, z) ? "1" : "0";

        return `bs-logic:bluestoneDust${up}${down}${left}${right}`;
    }

    canConnect(world, x, y, z) {
        const blockId = world.getBlockAt(x, y, z);
        if (blockId === this.id) return true;
        const block = Block.getById(blockId);
        if (!block) return false;
        return !!(block.isPowerSource || block.isBluestoneConsumer);
    }

    isSolid() { return false; }
    getCollisionBoundingBox() { return null; }
    getBoundingBox() { return new BoundingBox(0, 0, 0, 1, 0.0625, 1); }
    isTranslucent() { return true; }

    // ---------------------------------------------------------------
    // POWER
    // ---------------------------------------------------------------

    getPower(world, x, y, z) {
        const data = world.getBlockDataAt(x, y, z);
        return (typeof data === 'number' && data >= 0 && data <= MAX_POWER) ? data : 0;
    }

    calculatePower(world, x, y, z) {
        const neighbors = [
            [x + 1, y, z],
            [x - 1, y, z],
            [x, y, z + 1],
            [x, y, z - 1],
            [x, y - 1, z],
            [x, y + 1, z],
        ];

        let best = 0;

        for (const [nx, ny, nz] of neighbors) {
            const blockId = world.getBlockAt(nx, ny, nz);
            if (blockId === undefined || blockId === null || blockId === -1) continue;

            const block = Block.getById(blockId);

            // source constante -> puissance max directement
            if (block && block.isPowerSource) {
                return MAX_POWER;
            }

            // dust voisin -> on prend sa puissance - 1
            if (blockId === this.id) {
                const p = this.getPower(world, nx, ny, nz) - 1;
                if (p > best) best = p;
            }
        }

        return Math.max(0, best);
    }

    // schedule un tick sur tous les voisins dust + consumers
    _scheduleNeighbors(world, x, y, z) {
        const neighbors = [
            [x + 1, y, z],
            [x - 1, y, z],
            [x, y, z + 1],
            [x, y, z - 1],
            [x, y - 1, z],
            [x, y + 1, z],
        ];
        for (const [nx, ny, nz] of neighbors) {
            world.scheduleBlockTick(nx, ny, nz, TICK_DELAY);
        }
    }

    // ---------------------------------------------------------------
    // HOOKS
    // ---------------------------------------------------------------

    onBlockAdded(world, x, y, z) {
        // refresh visuel des connexions voisines
        world.onBlockChanged(x + 1, y, z);
        world.onBlockChanged(x - 1, y, z);
        world.onBlockChanged(x, y, z + 1);
        world.onBlockChanged(x, y, z - 1);

        // schedule notre propre tick pour calculer la puissance initiale
        world.scheduleBlockTick(x, y, z, TICK_DELAY);
    }

    onBlockRemoved(world, x, y, z) {
        // on force la metadata à 0 immédiatement
        world.setBlockDataAt(x, y, z, 0);
        // puis on schedule les voisins pour qu'ils se recalculent
        this._scheduleNeighbors(world, x, y, z);
    }

    onBlockTick(world, x, y, z) {
        if (world.getBlockAt(x, y, z) !== this.id) return;

        const newPower     = this.calculatePower(world, x, y, z);
        const currentPower = this.getPower(world, x, y, z);

        if (newPower !== currentPower) {
            world.setBlockDataAt(x, y, z, newPower);
            world.onBlockChanged(x, y, z); // refresh couleur + texture

            // propager le changement aux voisins
            this._scheduleNeighbors(world, x, y, z);
        }
    }

    // ---------------------------------------------------------------
    // COLOR
    // ---------------------------------------------------------------

    getColor(world, x, y, z, face) {
        const power = (world && typeof x === 'number')
            ? this.getPower(world, x, y, z)
            : 0;
        const t = power / MAX_POWER;

        const min = { r: 0x18, g: 0x1A, b: 0x38 }; // bleu terne
        const max = { r: 0x30, g: 0x70, b: 0xFF }; // bleu vif

        const r = Math.round(min.r + (max.r - min.r) * t);
        const g = Math.round(min.g + (max.g - min.g) * t);
        const b = Math.round(min.b + (max.b - min.b) * t);

        return (r << 16) | (g << 8) | b;
    }
}